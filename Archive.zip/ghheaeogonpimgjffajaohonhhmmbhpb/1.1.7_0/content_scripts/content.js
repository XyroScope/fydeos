var FYDEOS_REMOTE_DESKTOP_ORIGIN = 'https://remotedesktop.fydeos.com';

chrome.runtime.onMessage.addListener(function (request, sender, sendResponse) {
    // console.log(request);
    if (request.accessCode) {
        window.postMessage( { accessCode: request.accessCode }, FYDEOS_REMOTE_DESKTOP_ORIGIN );
    }
    if (request.reset) {
        window.postMessage( { reset: 'true' }, FYDEOS_REMOTE_DESKTOP_ORIGIN );
    }
    if (request.connected) {
        window.postMessage( { connected: 'true' }, FYDEOS_REMOTE_DESKTOP_ORIGIN );
    }
});
