# FydeOS Remote Desktop

FydeOS Remote Desktop 的 Chrome extension，配合 [fydeos-remote-desktop-web](https://gitlab.fydeos.xyz/fydeos-extensions/fydeos-remote-desktop-web) 一起使用。

## URL 说明

**global.js**

`FYDEOS_SOCKET_URL` 是 socket 服务的地址。

`FYDEOS_REMOTE_DESKTOP_URL` 是点击插件图标打开的网页。`FYDEOS_REMOTE_DESKTOP_URL` 是 `FYDEOS_REMOTE_DESKTOP_URL` 的 wildcard，用来在浏览器查询 tab。

**dropdown.js**

`FYDEOS_REMOTE_DESKTOP_URL` 是点击插件图标打开的网页。`FYDEOS_REMOTE_DESKTOP_URL` 是 `FYDEOS_REMOTE_DESKTOP_URL` 的 wildcard，用来在浏览器查询 tab。

**content.js**

`FYDEOS_REMOTE_DESKTOP_ORIGIN` 应和 `VUE_APP_FYDEOS_REMOTE_DESKTOP_ORIGIN` 相同。
