// IceServersHandler.js

var IceServersHandler = (function() {
    function getIceServers(connection) {
        var iceServers = [
            {
                'urls': [
                    'stun:52.80.252.193:3478',
                ],
                'username': 'fydeos',
                'credential': 'AprnyzZA398ZLk8e',
            },
            {
                'urls': [
                    'turn:52.80.252.193:3478',
                ],
                'username': 'fydeos',
                'credential': 'AprnyzZA398ZLk8e',
            },
            // {
            //     'urls': [
            //         'stun:stun.l.google.com:19302',
            //         'stun:stun1.l.google.com:19302',
            //         'stun:stun2.l.google.com:19302',
            //         'stun:stun.l.google.com:19302?transport=udp',
            //     ]
            // }
        ];

        return iceServers;
    }

    return {
        getIceServers: getIceServers
    };
})();
