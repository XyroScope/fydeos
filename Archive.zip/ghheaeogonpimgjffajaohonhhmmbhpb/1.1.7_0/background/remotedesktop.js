chrome.runtime.onMessageExternal.addListener(
    function(request, sender, sendResponse) {
        if (request.action === 'ping') {
            sendResponse({ msg: 'pong' });
        } else if (request.action === 'generateAccessCode') {;
            sendResponse({ msg: 'generating' });
            chrome.storage.sync.set({
                enableTabCaptureAPI: 'false',
                enableMicrophone: 'false',
                enableCamera: 'false',
                enableScreen: 'true',
                isSharingOn: 'true',
                enableSpeakers: 'false',
            }, function() {
                captureDesktop();
            });
        } else if (request.action === 'destroyAccessCode') {
            sendResponse({ msg: 'destroying' });
            chrome.storage.sync.set({
                isSharingOn: 'false'
            }, function () {
                captureDesktop();
                window.close();
            });
        }
});
