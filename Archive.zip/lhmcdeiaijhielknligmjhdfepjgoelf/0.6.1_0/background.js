chrome.app.runtime.onLaunched.addListener(function() {
  chrome.app.window.create('index.html', {
    bounds: {
      width: 720,
      height: 450,
    },
    resizable: false,
    maxWidth: 720,
    minWidth: 720,
    maxHeight: 450,
    minHeight: 450,
  });
});
